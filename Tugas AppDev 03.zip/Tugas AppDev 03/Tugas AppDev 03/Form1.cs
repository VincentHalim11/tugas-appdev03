﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tugas_AppDev_03
{
    public partial class Form1 : Form
    {
        Point menu = new Point(12,12);
        Point tunggu = new Point(256,13);
        Point tunggu2 = new Point(490, 13);
        Point tunggu3 = new Point(13, 227);
        Point tunggu4 = new Point(256, 227);
        List<string>Username = new List<string>();
        List<string>Password = new List<string>();
        List<int> Saldo = new List<int>();
        private int dana = 0;
        private int transfer = 0;
        private int duit = 0;
        private int tarik = 0;
        
       
        
        public Form1()
        {
            InitializeComponent();
        }
        // menu login
        private void btn_login_Click(object sender, EventArgs e)
        {
            int saldos = Username.IndexOf(txt_user.Text);
            while(dana != saldos)
            {
                if(dana < saldos)
                {
                    dana++;
                }
                else if(dana> saldos)
                {
                    dana--;
                }
            }

            if(txt_user.Text == "" &&  txt_password.Text == "")
            {
                MessageBox.Show("belum memasukan username atau password");
            }
            else if (Username.IndexOf(txt_user.Text) == Password.IndexOf(txt_pass.Text)
                && Username.Contains(txt_user.Text) && Password.Contains(txt_pass.Text) )
            {
                btn_unhide.Visible = true;
                this.pnl_uang.Location = menu;
                lbl_uang.Text = Saldo[dana].ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                lbl_money.Text =Saldo[dana].ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                MessageBox.Show("Login berhasil");
            }
            else
            {
                MessageBox.Show("password atau username salah");
            }
            txt_pass.Clear();
            txt_user.Clear();
        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            this.pnl_register.Location = menu;
            
        }

        //registrasi
        private void btn_buat_Click(object sender, EventArgs e)
        {
            if (Username.Contains(txt_username.Text))
            {
                MessageBox.Show("Username sudah ada");
            }
            else
            {
                MessageBox.Show("jadi bang");
                Username.Add(txt_username.Text);
                Password.Add(txt_password.Text);
                Saldo.Add(0);
                this.pnl_register.Location = tunggu;
            }
            btn_muncul.Visible = true;
            txt_username.Clear();
            txt_password.Clear();
           
        }

        //menu bank
        private void btn_logout_Click(object sender, EventArgs e)
        {
            this.pnl_uang.Location = tunggu2;
            this.pnl_deposit.Location = tunggu3;
            this.pnl_withdraw.Location = tunggu4;
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.pnl_deposit.Location = tunggu3;
            this.pnl_withdraw.Location = tunggu4;
        }

        private void btn_deposit_Click(object sender, EventArgs e)
        {
            this.pnl_deposit.Location = menu;
        }

        private void btn_withdraw_Click(object sender, EventArgs e)
        {
            this.pnl_withdraw.Location = menu;
        }

        private void btn_transfer_Click(object sender, EventArgs e)
        {
           
               
            transfer = Convert.ToInt32(txt_deposit.Text);
            if (transfer <= 0)
            {
                MessageBox.Show("G bisa kurang dari 0");
            }
            else
            {
                Saldo[dana] = Saldo[dana] + transfer;
                lbl_uang.Text = Saldo[dana].ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                lbl_money.Text = Saldo[dana].ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                MessageBox.Show("Berhasil");
                txt_deposit.Clear();
                this.pnl_deposit.Location = tunggu3;
            }
        
        }

        private void btn_tarik_Click(object sender, EventArgs e)
        {
     
            tarik = Convert.ToInt32(txt_withdraw.Text);
            if (Saldo[dana] < tarik)
            {
                MessageBox.Show("Uang anda g cukup");
            }
            else if (tarik <= 0)
            {
                MessageBox.Show("G bisa kurang dari 0");
            }
            else
            {

                Saldo[dana] = Saldo[dana] - tarik;
                lbl_uang.Text = Saldo[dana].ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                lbl_money.Text = Saldo[dana].ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
                txt_withdraw.Clear();
                this.pnl_withdraw.Location = tunggu4;
            }
 
        }


        //hide unhide password
        private void btn_hide_Click(object sender, EventArgs e)
        {
            if (txt_pass.PasswordChar == '\0')
            {
                btn_unhide.Visible = true;
                txt_pass.PasswordChar = '*';
            }
           
        }

        private void btn_unhide_Click(object sender, EventArgs e)
        {
            if (txt_pass.PasswordChar == '*')
            {
                btn_unhide.Visible = false;
                txt_pass.PasswordChar = '\0';
            }
        }

        private void btn_muncul_Click(object sender, EventArgs e)
        {
            if (txt_password.PasswordChar == '*')
            {
                btn_muncul.Visible = false;
                txt_password.PasswordChar = '\0';
            }
        }

        private void btn_ilang_Click(object sender, EventArgs e)
        {
            
            if (txt_password.PasswordChar == '\0')
            {
                btn_muncul.Visible = true;
                txt_password.PasswordChar = '*';
            }
        }

        private void txt_pass_TextChanged(object sender, EventArgs e)
        {
            txt_pass.PasswordChar = '*';
        }

        private void txt_password_TextChanged(object sender, EventArgs e)
        {
            txt_password.PasswordChar = '*';
        }

        
    }
}
