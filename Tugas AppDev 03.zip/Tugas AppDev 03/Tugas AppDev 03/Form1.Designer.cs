﻿namespace Tugas_AppDev_03
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_menu = new System.Windows.Forms.Panel();
            this.btn_register = new System.Windows.Forms.Button();
            this.btn_login = new System.Windows.Forms.Button();
            this.txt_pass = new System.Windows.Forms.TextBox();
            this.txt_user = new System.Windows.Forms.TextBox();
            this.lbl_pass = new System.Windows.Forms.Label();
            this.lbl_username = new System.Windows.Forms.Label();
            this.lbl_uc = new System.Windows.Forms.Label();
            this.btn_unhide = new System.Windows.Forms.Button();
            this.btn_hide = new System.Windows.Forms.Button();
            this.pnl_register = new System.Windows.Forms.Panel();
            this.btn_buat = new System.Windows.Forms.Button();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.lbl_uc2 = new System.Windows.Forms.Label();
            this.txt_username = new System.Windows.Forms.TextBox();
            this.lbl_password = new System.Windows.Forms.Label();
            this.lbl_registrasi = new System.Windows.Forms.Label();
            this.btn_muncul = new System.Windows.Forms.Button();
            this.btn_ilang = new System.Windows.Forms.Button();
            this.pnl_uang = new System.Windows.Forms.Panel();
            this.btn_withdraw = new System.Windows.Forms.Button();
            this.btn_deposit = new System.Windows.Forms.Button();
            this.lbl_uang = new System.Windows.Forms.Label();
            this.lbl_balance = new System.Windows.Forms.Label();
            this.btn_logout = new System.Windows.Forms.Button();
            this.lbl_uc3 = new System.Windows.Forms.Label();
            this.pnl_deposit = new System.Windows.Forms.Panel();
            this.btn_back = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txt_deposit = new System.Windows.Forms.TextBox();
            this.btn_transfer = new System.Windows.Forms.Button();
            this.lbl_deposit = new System.Windows.Forms.Label();
            this.lbl_uc4 = new System.Windows.Forms.Label();
            this.pnl_withdraw = new System.Windows.Forms.Panel();
            this.btn_back2 = new System.Windows.Forms.Button();
            this.lbl_money = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.txt_withdraw = new System.Windows.Forms.TextBox();
            this.btn_tarik = new System.Windows.Forms.Button();
            this.lbl_withdraw = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pnl_menu.SuspendLayout();
            this.pnl_register.SuspendLayout();
            this.pnl_uang.SuspendLayout();
            this.pnl_deposit.SuspendLayout();
            this.pnl_withdraw.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_menu
            // 
            this.pnl_menu.Controls.Add(this.btn_register);
            this.pnl_menu.Controls.Add(this.btn_login);
            this.pnl_menu.Controls.Add(this.txt_pass);
            this.pnl_menu.Controls.Add(this.txt_user);
            this.pnl_menu.Controls.Add(this.lbl_pass);
            this.pnl_menu.Controls.Add(this.lbl_username);
            this.pnl_menu.Controls.Add(this.lbl_uc);
            this.pnl_menu.Controls.Add(this.btn_unhide);
            this.pnl_menu.Controls.Add(this.btn_hide);
            this.pnl_menu.Location = new System.Drawing.Point(12, 12);
            this.pnl_menu.Name = "pnl_menu";
            this.pnl_menu.Size = new System.Drawing.Size(229, 209);
            this.pnl_menu.TabIndex = 0;
            // 
            // btn_register
            // 
            this.btn_register.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_register.Location = new System.Drawing.Point(77, 166);
            this.btn_register.Name = "btn_register";
            this.btn_register.Size = new System.Drawing.Size(60, 20);
            this.btn_register.TabIndex = 8;
            this.btn_register.Text = "Register";
            this.btn_register.UseVisualStyleBackColor = true;
            this.btn_register.Click += new System.EventHandler(this.btn_register_Click);
            // 
            // btn_login
            // 
            this.btn_login.Font = new System.Drawing.Font("Microsoft JhengHei UI", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.Location = new System.Drawing.Point(77, 140);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(60, 20);
            this.btn_login.TabIndex = 7;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // txt_pass
            // 
            this.txt_pass.Location = new System.Drawing.Point(77, 104);
            this.txt_pass.Name = "txt_pass";
            this.txt_pass.Size = new System.Drawing.Size(100, 20);
            this.txt_pass.TabIndex = 4;
            this.txt_pass.TextChanged += new System.EventHandler(this.txt_pass_TextChanged);
            // 
            // txt_user
            // 
            this.txt_user.Location = new System.Drawing.Point(77, 72);
            this.txt_user.Name = "txt_user";
            this.txt_user.Size = new System.Drawing.Size(100, 20);
            this.txt_user.TabIndex = 3;
            // 
            // lbl_pass
            // 
            this.lbl_pass.AutoSize = true;
            this.lbl_pass.Location = new System.Drawing.Point(14, 104);
            this.lbl_pass.Name = "lbl_pass";
            this.lbl_pass.Size = new System.Drawing.Size(59, 13);
            this.lbl_pass.TabIndex = 2;
            this.lbl_pass.Text = "Password :";
            // 
            // lbl_username
            // 
            this.lbl_username.AutoSize = true;
            this.lbl_username.Location = new System.Drawing.Point(14, 72);
            this.lbl_username.Name = "lbl_username";
            this.lbl_username.Size = new System.Drawing.Size(61, 13);
            this.lbl_username.TabIndex = 1;
            this.lbl_username.Text = "Username :";
            // 
            // lbl_uc
            // 
            this.lbl_uc.AutoSize = true;
            this.lbl_uc.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_uc.Location = new System.Drawing.Point(36, 18);
            this.lbl_uc.Name = "lbl_uc";
            this.lbl_uc.Size = new System.Drawing.Size(150, 33);
            this.lbl_uc.TabIndex = 0;
            this.lbl_uc.Text = "UC BANK";
            // 
            // btn_unhide
            // 
            this.btn_unhide.Location = new System.Drawing.Point(183, 104);
            this.btn_unhide.Name = "btn_unhide";
            this.btn_unhide.Size = new System.Drawing.Size(21, 24);
            this.btn_unhide.TabIndex = 6;
            this.btn_unhide.Text = "U";
            this.btn_unhide.UseVisualStyleBackColor = true;
            this.btn_unhide.Click += new System.EventHandler(this.btn_unhide_Click);
            // 
            // btn_hide
            // 
            this.btn_hide.Location = new System.Drawing.Point(183, 104);
            this.btn_hide.Name = "btn_hide";
            this.btn_hide.Size = new System.Drawing.Size(21, 23);
            this.btn_hide.TabIndex = 5;
            this.btn_hide.Text = "H";
            this.btn_hide.UseVisualStyleBackColor = true;
            this.btn_hide.Click += new System.EventHandler(this.btn_hide_Click);
            // 
            // pnl_register
            // 
            this.pnl_register.Controls.Add(this.btn_buat);
            this.pnl_register.Controls.Add(this.txt_password);
            this.pnl_register.Controls.Add(this.lbl_uc2);
            this.pnl_register.Controls.Add(this.txt_username);
            this.pnl_register.Controls.Add(this.lbl_password);
            this.pnl_register.Controls.Add(this.lbl_registrasi);
            this.pnl_register.Controls.Add(this.btn_muncul);
            this.pnl_register.Controls.Add(this.btn_ilang);
            this.pnl_register.Location = new System.Drawing.Point(256, 13);
            this.pnl_register.Name = "pnl_register";
            this.pnl_register.Size = new System.Drawing.Size(228, 208);
            this.pnl_register.TabIndex = 1;
            // 
            // btn_buat
            // 
            this.btn_buat.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_buat.Location = new System.Drawing.Point(75, 139);
            this.btn_buat.Name = "btn_buat";
            this.btn_buat.Size = new System.Drawing.Size(60, 20);
            this.btn_buat.TabIndex = 9;
            this.btn_buat.Text = "Register";
            this.btn_buat.UseVisualStyleBackColor = true;
            this.btn_buat.Click += new System.EventHandler(this.btn_buat_Click);
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(75, 103);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(100, 20);
            this.txt_password.TabIndex = 12;
            this.txt_password.TextChanged += new System.EventHandler(this.txt_password_TextChanged);
            // 
            // lbl_uc2
            // 
            this.lbl_uc2.AutoSize = true;
            this.lbl_uc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_uc2.Location = new System.Drawing.Point(34, 17);
            this.lbl_uc2.Name = "lbl_uc2";
            this.lbl_uc2.Size = new System.Drawing.Size(150, 33);
            this.lbl_uc2.TabIndex = 9;
            this.lbl_uc2.Text = "UC BANK";
            // 
            // txt_username
            // 
            this.txt_username.Location = new System.Drawing.Point(75, 71);
            this.txt_username.Name = "txt_username";
            this.txt_username.Size = new System.Drawing.Size(100, 20);
            this.txt_username.TabIndex = 11;
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Location = new System.Drawing.Point(12, 103);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(59, 13);
            this.lbl_password.TabIndex = 10;
            this.lbl_password.Text = "Password :";
            // 
            // lbl_registrasi
            // 
            this.lbl_registrasi.AutoSize = true;
            this.lbl_registrasi.Location = new System.Drawing.Point(12, 71);
            this.lbl_registrasi.Name = "lbl_registrasi";
            this.lbl_registrasi.Size = new System.Drawing.Size(61, 13);
            this.lbl_registrasi.TabIndex = 9;
            this.lbl_registrasi.Text = "Username :";
            // 
            // btn_muncul
            // 
            this.btn_muncul.Location = new System.Drawing.Point(181, 104);
            this.btn_muncul.Name = "btn_muncul";
            this.btn_muncul.Size = new System.Drawing.Size(21, 24);
            this.btn_muncul.TabIndex = 14;
            this.btn_muncul.Text = "U";
            this.btn_muncul.UseVisualStyleBackColor = true;
            this.btn_muncul.Click += new System.EventHandler(this.btn_muncul_Click);
            // 
            // btn_ilang
            // 
            this.btn_ilang.Location = new System.Drawing.Point(181, 103);
            this.btn_ilang.Name = "btn_ilang";
            this.btn_ilang.Size = new System.Drawing.Size(21, 23);
            this.btn_ilang.TabIndex = 13;
            this.btn_ilang.Text = "H";
            this.btn_ilang.UseVisualStyleBackColor = true;
            this.btn_ilang.Click += new System.EventHandler(this.btn_ilang_Click);
            // 
            // pnl_uang
            // 
            this.pnl_uang.Controls.Add(this.btn_withdraw);
            this.pnl_uang.Controls.Add(this.btn_deposit);
            this.pnl_uang.Controls.Add(this.lbl_uang);
            this.pnl_uang.Controls.Add(this.lbl_balance);
            this.pnl_uang.Controls.Add(this.btn_logout);
            this.pnl_uang.Controls.Add(this.lbl_uc3);
            this.pnl_uang.Location = new System.Drawing.Point(490, 13);
            this.pnl_uang.Name = "pnl_uang";
            this.pnl_uang.Size = new System.Drawing.Size(228, 208);
            this.pnl_uang.TabIndex = 2;
            // 
            // btn_withdraw
            // 
            this.btn_withdraw.Location = new System.Drawing.Point(77, 165);
            this.btn_withdraw.Name = "btn_withdraw";
            this.btn_withdraw.Size = new System.Drawing.Size(75, 23);
            this.btn_withdraw.TabIndex = 20;
            this.btn_withdraw.Text = "Withdraw";
            this.btn_withdraw.UseVisualStyleBackColor = true;
            this.btn_withdraw.Click += new System.EventHandler(this.btn_withdraw_Click);
            // 
            // btn_deposit
            // 
            this.btn_deposit.Location = new System.Drawing.Point(77, 136);
            this.btn_deposit.Name = "btn_deposit";
            this.btn_deposit.Size = new System.Drawing.Size(75, 23);
            this.btn_deposit.TabIndex = 19;
            this.btn_deposit.Text = "Deposit";
            this.btn_deposit.UseVisualStyleBackColor = true;
            this.btn_deposit.Click += new System.EventHandler(this.btn_deposit_Click);
            // 
            // lbl_uang
            // 
            this.lbl_uang.AutoSize = true;
            this.lbl_uang.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_uang.Location = new System.Drawing.Point(72, 104);
            this.lbl_uang.Name = "lbl_uang";
            this.lbl_uang.Size = new System.Drawing.Size(67, 20);
            this.lbl_uang.TabIndex = 18;
            this.lbl_uang.Text = "Rp0,00";
            // 
            // lbl_balance
            // 
            this.lbl_balance.AutoSize = true;
            this.lbl_balance.Location = new System.Drawing.Point(15, 106);
            this.lbl_balance.Name = "lbl_balance";
            this.lbl_balance.Size = new System.Drawing.Size(51, 13);
            this.lbl_balance.TabIndex = 17;
            this.lbl_balance.Text = "balance :";
            // 
            // btn_logout
            // 
            this.btn_logout.Location = new System.Drawing.Point(135, 53);
            this.btn_logout.Name = "btn_logout";
            this.btn_logout.Size = new System.Drawing.Size(70, 23);
            this.btn_logout.TabIndex = 16;
            this.btn_logout.Text = "Logout";
            this.btn_logout.UseVisualStyleBackColor = true;
            this.btn_logout.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // lbl_uc3
            // 
            this.lbl_uc3.AutoSize = true;
            this.lbl_uc3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_uc3.Location = new System.Drawing.Point(35, 17);
            this.lbl_uc3.Name = "lbl_uc3";
            this.lbl_uc3.Size = new System.Drawing.Size(150, 33);
            this.lbl_uc3.TabIndex = 15;
            this.lbl_uc3.Text = "UC BANK";
            // 
            // pnl_deposit
            // 
            this.pnl_deposit.Controls.Add(this.btn_back);
            this.pnl_deposit.Controls.Add(this.button1);
            this.pnl_deposit.Controls.Add(this.txt_deposit);
            this.pnl_deposit.Controls.Add(this.btn_transfer);
            this.pnl_deposit.Controls.Add(this.lbl_deposit);
            this.pnl_deposit.Controls.Add(this.lbl_uc4);
            this.pnl_deposit.Location = new System.Drawing.Point(13, 227);
            this.pnl_deposit.Name = "pnl_deposit";
            this.pnl_deposit.Size = new System.Drawing.Size(228, 208);
            this.pnl_deposit.TabIndex = 21;
            // 
            // btn_back
            // 
            this.btn_back.Location = new System.Drawing.Point(16, 63);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(70, 23);
            this.btn_back.TabIndex = 22;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(145, 63);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 23);
            this.button1.TabIndex = 21;
            this.button1.Text = "Logout";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // txt_deposit
            // 
            this.txt_deposit.Location = new System.Drawing.Point(55, 130);
            this.txt_deposit.Name = "txt_deposit";
            this.txt_deposit.Size = new System.Drawing.Size(100, 20);
            this.txt_deposit.TabIndex = 9;
            // 
            // btn_transfer
            // 
            this.btn_transfer.Location = new System.Drawing.Point(68, 165);
            this.btn_transfer.Name = "btn_transfer";
            this.btn_transfer.Size = new System.Drawing.Size(75, 23);
            this.btn_transfer.TabIndex = 19;
            this.btn_transfer.Text = "Deposit";
            this.btn_transfer.UseVisualStyleBackColor = true;
            this.btn_transfer.Click += new System.EventHandler(this.btn_transfer_Click);
            // 
            // lbl_deposit
            // 
            this.lbl_deposit.AutoSize = true;
            this.lbl_deposit.Location = new System.Drawing.Point(52, 103);
            this.lbl_deposit.Name = "lbl_deposit";
            this.lbl_deposit.Size = new System.Drawing.Size(115, 13);
            this.lbl_deposit.TabIndex = 17;
            this.lbl_deposit.Text = "Input Deposit Amount :";
            // 
            // lbl_uc4
            // 
            this.lbl_uc4.AutoSize = true;
            this.lbl_uc4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_uc4.Location = new System.Drawing.Point(35, 17);
            this.lbl_uc4.Name = "lbl_uc4";
            this.lbl_uc4.Size = new System.Drawing.Size(150, 33);
            this.lbl_uc4.TabIndex = 15;
            this.lbl_uc4.Text = "UC BANK";
            // 
            // pnl_withdraw
            // 
            this.pnl_withdraw.Controls.Add(this.btn_back2);
            this.pnl_withdraw.Controls.Add(this.lbl_money);
            this.pnl_withdraw.Controls.Add(this.label1);
            this.pnl_withdraw.Controls.Add(this.button2);
            this.pnl_withdraw.Controls.Add(this.txt_withdraw);
            this.pnl_withdraw.Controls.Add(this.btn_tarik);
            this.pnl_withdraw.Controls.Add(this.lbl_withdraw);
            this.pnl_withdraw.Controls.Add(this.label2);
            this.pnl_withdraw.Location = new System.Drawing.Point(256, 227);
            this.pnl_withdraw.Name = "pnl_withdraw";
            this.pnl_withdraw.Size = new System.Drawing.Size(228, 208);
            this.pnl_withdraw.TabIndex = 22;
            // 
            // btn_back2
            // 
            this.btn_back2.Location = new System.Drawing.Point(15, 63);
            this.btn_back2.Name = "btn_back2";
            this.btn_back2.Size = new System.Drawing.Size(70, 23);
            this.btn_back2.TabIndex = 22;
            this.btn_back2.Text = "Back";
            this.btn_back2.UseVisualStyleBackColor = true;
            this.btn_back2.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // lbl_money
            // 
            this.lbl_money.AutoSize = true;
            this.lbl_money.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_money.Location = new System.Drawing.Point(68, 98);
            this.lbl_money.Name = "lbl_money";
            this.lbl_money.Size = new System.Drawing.Size(67, 20);
            this.lbl_money.TabIndex = 21;
            this.lbl_money.Text = "Rp0,00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "balance :";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(132, 63);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(70, 23);
            this.button2.TabIndex = 21;
            this.button2.Text = "Logout";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btn_logout_Click);
            // 
            // txt_withdraw
            // 
            this.txt_withdraw.Location = new System.Drawing.Point(63, 151);
            this.txt_withdraw.Name = "txt_withdraw";
            this.txt_withdraw.Size = new System.Drawing.Size(100, 20);
            this.txt_withdraw.TabIndex = 9;
            // 
            // btn_tarik
            // 
            this.btn_tarik.Location = new System.Drawing.Point(75, 177);
            this.btn_tarik.Name = "btn_tarik";
            this.btn_tarik.Size = new System.Drawing.Size(75, 23);
            this.btn_tarik.TabIndex = 19;
            this.btn_tarik.Text = "Withdraw";
            this.btn_tarik.UseVisualStyleBackColor = true;
            this.btn_tarik.Click += new System.EventHandler(this.btn_tarik_Click);
            // 
            // lbl_withdraw
            // 
            this.lbl_withdraw.AutoSize = true;
            this.lbl_withdraw.Location = new System.Drawing.Point(51, 130);
            this.lbl_withdraw.Name = "lbl_withdraw";
            this.lbl_withdraw.Size = new System.Drawing.Size(124, 13);
            this.lbl_withdraw.TabIndex = 17;
            this.lbl_withdraw.Text = "Input Withdraw Amount :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 33);
            this.label2.TabIndex = 15;
            this.label2.Text = "UC BANK";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(246, 226);
            this.Controls.Add(this.pnl_withdraw);
            this.Controls.Add(this.pnl_deposit);
            this.Controls.Add(this.pnl_uang);
            this.Controls.Add(this.pnl_register);
            this.Controls.Add(this.pnl_menu);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnl_menu.ResumeLayout(false);
            this.pnl_menu.PerformLayout();
            this.pnl_register.ResumeLayout(false);
            this.pnl_register.PerformLayout();
            this.pnl_uang.ResumeLayout(false);
            this.pnl_uang.PerformLayout();
            this.pnl_deposit.ResumeLayout(false);
            this.pnl_deposit.PerformLayout();
            this.pnl_withdraw.ResumeLayout(false);
            this.pnl_withdraw.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_menu;
        private System.Windows.Forms.Label lbl_uc;
        private System.Windows.Forms.TextBox txt_user;
        private System.Windows.Forms.Label lbl_pass;
        private System.Windows.Forms.Label lbl_username;
        private System.Windows.Forms.Button btn_hide;
        private System.Windows.Forms.TextBox txt_pass;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_unhide;
        private System.Windows.Forms.Button btn_register;
        private System.Windows.Forms.Panel pnl_register;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Label lbl_uc2;
        private System.Windows.Forms.TextBox txt_username;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.Label lbl_registrasi;
        private System.Windows.Forms.Button btn_muncul;
        private System.Windows.Forms.Button btn_ilang;
        private System.Windows.Forms.Button btn_buat;
        private System.Windows.Forms.Panel pnl_uang;
        private System.Windows.Forms.Label lbl_uc3;
        private System.Windows.Forms.Button btn_logout;
        private System.Windows.Forms.Label lbl_uang;
        private System.Windows.Forms.Label lbl_balance;
        private System.Windows.Forms.Button btn_withdraw;
        private System.Windows.Forms.Button btn_deposit;
        private System.Windows.Forms.Panel pnl_deposit;
        private System.Windows.Forms.TextBox txt_deposit;
        private System.Windows.Forms.Button btn_transfer;
        private System.Windows.Forms.Label lbl_deposit;
        private System.Windows.Forms.Label lbl_uc4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel pnl_withdraw;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txt_withdraw;
        private System.Windows.Forms.Button btn_tarik;
        private System.Windows.Forms.Label lbl_withdraw;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_money;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Button btn_back2;
    }
}

